/* -*- Mode: C; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2; -*- */
#include <stdio.h>

int main(int argc, char *argv[])
{
  int n, precio, cantidad, i, contador;
  float promo = 0.2;
  int parcial = 0, total, subtotal = 0, descuento = 0, pago, vuelto, desglose;
  printf("n=", n);
  scanf("%d", &n);

  printf("Cantidad productos: ");
  scanf("%d", &cantidad);

  for(i = 1; i <= cantidad; i++)
    {
      printf("Precio Producto %d: ", i);
      scanf("%d", &precio);
      subtotal += precio;
      parcial += precio;
      if(i != 0 && i % n == 0)
        {
          descuento += (int) parcial * promo; //redondear
          promo /= 2;
          parcial = 0;
        }
    }
  printf("Sub-Total: %d\n", subtotal);
  printf("Descuento %d\n", descuento);
  total = subtotal - descuento;
  printf("Total: %d\n", total);
  printf("Pago: ");
  scanf("%d", &pago);
  vuelto = pago - total;
  printf("Vuelto: %d\n", vuelto);

  // Desglose del vuelto
  desglose = vuelto / 20000;
  vuelto %= 20000;
  if(desglose == 1)
    printf("1 billete de 20000 Pesos\n");
  else if(desglose != 0)
    printf("%d billetes de 20000 Pesos\n", desglose);

  desglose = vuelto / 10000;
  vuelto %= 10000;
  if(desglose == 1)
    printf("1 billete de 10000 Pesos\n");
  else
    printf("%d billetes de 10000 Pesos\n", desglose);

  desglose = vuelto / 5000;
  vuelto %= 5000;
  if(desglose == 1)
    printf("1 billete de 5000 Pesos\n");
  else if(desglose != 0)
    printf("%d billetes de 5000 Pesos\n", desglose);

  desglose = vuelto / 2000;
  vuelto %= 2000;
  if(desglose == 1)
    printf("1 billete de 2000 Pesos\n");
  else if(desglose != 0)
    printf("%d billetes de 2000 Pesos\n", desglose);

  desglose = vuelto / 1000;
  vuelto %= 1000;
  if(desglose == 1)
    printf("1 billete de 1000 Pesos\n");
  else if(desglose != 0)
    printf("%d billetes de 1000 Pesos\n", desglose);

  desglose = vuelto / 500;
  vuelto %= 500;
  if(desglose == 1)
    printf("1 moneda de 500 Pesos\n");
  else if(desglose != 0)
    printf("%d monedas de 500 Pesos\n", desglose);

  desglose = vuelto / 100;
  vuelto %= 100;
  if(desglose == 1)
    printf("1 moneda de 100 Pesos\n");
  else if(desglose != 0)
    printf("%d monedas de 100 Pesos\n", desglose);

  desglose = vuelto / 50;
  vuelto %= 50;
  if(desglose == 1)
    printf("1 moneda de 50 Pesos\n");
  else if(desglose != 0)
    printf("%d monedas de 50 Pesos\n", desglose);

  desglose = vuelto / 10;
  vuelto %= 10;
  if(desglose == 1)
    printf("1 moneda de 10 Pesos\n");
  else if(desglose != 0)
    printf("%d monedas de 10 Pesos\n", desglose);

  desglose = vuelto / 5;
  vuelto %= 5;
  if(desglose == 1)
    printf("1 moneda de 5 Pesos\n");
  else if(desglose != 0)
    printf("%d monedas de 5 Pesos\n", desglose);

  desglose = vuelto / 1;
  vuelto %= 1;
  if(desglose == 1)
    printf("1 moneda de 1 Pesos\n");
  else if(desglose != 0)
    printf("%d monedas de 1 Pesos\n", desglose);

  return 0;
}
