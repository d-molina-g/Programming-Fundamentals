/* -*- Mode: C; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2; -*- */
#include <stdio.h>
#include <stdbool.h>

int main(int argc, char *argv[])
{
  int n, i;
  int u_aceptan = 0, u_rechazan = 0, u_empate = 0, aceptan, rechazan, nulos, blancos;
  char voto;
  char univ[100];

  printf("Número de universidades: ");
  scanf("%d", &n);
  for(i=0; i < n; i++)
    {
      aceptan = 0;
      rechazan = 0;
      nulos = 0;
      blancos = 0;
      printf("Universidad: ");
      scanf("%s", univ);
      while(true)
        {
          printf("Voto: \n");
          scanf("%c", &voto);
          if(voto == 'A')
            aceptan++;
          else if(voto == 'R')
            rechazan++;
          else if(voto == 'N')
            nulos++;
          else if(voto == 'B')
            blancos++;
          else if(voto == 'X')
            break;
        }
      printf("%s: %d aceptan, %d rechazan, %d blancos, %d nulos\n", aceptan, rechazan, blancos, nulos);
      if(aceptan > rechazan)
        u_aceptan++;
      else if(rechazan > aceptan)
        u_rechazan++;
      else
        u_empate++;
    }
  printf("Universidades que aceptan: %d", u_aceptan);
  printf("Universidades que rechazan: %d", u_rechazan);
  printf("Universidades que empate: %d", u_empate);
  return 0;
}
