/* -*- Mode: C; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2; -*- */
#include <stdio.h>
#include <stdbool.h>
#include <math.h>

int main(int argc, char *argv[])
{
  int n, aux;
  int primero, ultimo;
  int largo = 0, contador = 0, largo2 = 0;
  bool aviso = true;
  printf("Ingrese un número:\n");
  scanf("%d", &n);
  aux = n;
  /* Saber el número de digitos del número */
  while(aux > 0)
    {
      aux = aux / 10;
      largo++;
    }
  aux = n;
  printf("largo %d\n", largo);
  largo2 = largo;
  /* Invertir y comprobar si el primero con el último son iguales */
  while(contador < largo/2)
    {
      ultimo = aux % 10; /* obtener el último digito */
      primero = n / pow(10, --largo2); /* obtener el primero, segundo, etc */
      primero = primero % 10;

      if(primero != ultimo )
        {
          aviso = false;
          break;
        }
      aux = aux / 10;
      contador++;
    }
  if(aviso)
    printf("El número %d es palíndromo\n", n);
  else
    printf("El número %d NO es palíndromo\n", n);
  return 0;
}
