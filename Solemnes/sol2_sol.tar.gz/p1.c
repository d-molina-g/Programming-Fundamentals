/* -*- Mode: C; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2; -*- */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAXTAM 80
#define N 10

void quitar_espacios(char cadenas[N][MAXTAM+1])
{
  int i, j, k;

  for(k = 0; k < N; k++)
    {
      char b[MAXTAM+1];
      b[0] = cadenas[k][0];
      j = 1;
      for(i = 1; i < strlen(cadenas[k]); i++)
	if(!isspace(cadenas[k][i]) || (isspace(cadenas[k][i]) && !isspace(cadenas[k][i-1])))
	  b[j++] = cadenas[k][i];
      b[j] = '\0';
      printf ("%s\n", b);
    }
}

int main(void)
{
  char a[N][MAXTAM+1];
  char aux[MAXTAM+1];
  int longitud , i, j;
  printf("Introduce una cadena (máx. %d cars.): ", MAXTAM);
  gets(aux);
  /* scanf("%s", a); */
  for(i = 0; i < N; i++)
    {
      strcpy(a[i], aux);
      printf("%s\n", a[i]);
    }

  quitar_espacios(a);

  return 0;
}
