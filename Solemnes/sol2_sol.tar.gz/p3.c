/* -*- Mode: C; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2; -*- */
#include<stdio.h>
#include<string.h>
#define TAM 50

int main(){
	char palabra[TAM];
	char encriptada[TAM];
	
	int i, j;
	int largoPalabra;
	int largoEncriptada;
	
	int iguales;
	
	while(scanf("%s %s", palabra, encriptada)> 0){
		largoPalabra = strlen(palabra);
		largoEncriptada = strlen(encriptada);
		iguales = 0;
		for(i=0, j=0; i< largoPalabra && j<largoEncriptada; ++i, ++j){
			for(; j<largoEncriptada; ++j){
				if(palabra[i] == encriptada[j]){
					++iguales;
					break;
				}
			}
		}
		
		if(iguales == largoPalabra){
			printf("Si\n");
		}
		else{
			printf("No\n");
		}
		
		
	}
	
	
	return 0;
}
