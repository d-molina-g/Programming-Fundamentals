/* -*- Mode: C; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2; -*- */
#include <stdio.h>
#include <stdlib.h>

#define TAM 100

void llenarMatriz(int M[TAM][TAM], int n){
  int i,j;
  for(i = 0; i < n; ++i)
    for(j = 0; j < n; ++j)
      scanf("%i", &M[i][j]);
}

int calculo(int M[TAM][TAM], int n, int arreglo []){
  int i, j;
  int tam = 0;
  int numero;
  for(i=0; i<n; ++i)
    {
      for(j=i; j<n-i; ++j)
        {
          numero = M[i][j]+M[n-1-i][j];
          arreglo[tam++] = numero;
        }
    }
  return tam;

}

void imprimir(int arreglo[], int tam){
  int i;
  for (i = 0; i < tam; ++i)
    printf("%i\n", arreglo[i]);

}


int main(int arcg, char **argv){

  int n,i;
  int M[TAM][TAM];
  int arreglo[TAM];
  int tam;
  scanf("%d", &n);

  llenarMatriz(M, n);
  tam = calculo(M, n, arreglo);
  imprimir(arreglo, tam);
}
